package com.starter.InvestAndChill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvestAndChillApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvestAndChillApplication.class, args);
	}

}
